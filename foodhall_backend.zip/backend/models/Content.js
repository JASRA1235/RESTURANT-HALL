
const mongoose = require("mongoose");

const contentSchema = new mongoose.Schema({
    section: String,
    text: String,
    image: String,
});

module.exports = mongoose.model("Content", contentSchema);
