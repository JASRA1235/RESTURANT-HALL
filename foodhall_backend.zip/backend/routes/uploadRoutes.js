
const express = require("express");
const Content = require("../models/Content");
const verifyToken = require("../middleware/verifyToken");
const router = express.Router();

router.post("/image", verifyToken, async (req, res) => {
    const { section, image } = req.body;
    try {
        const updated = await Content.findOneAndUpdate(
            { section },
            { image },
            { upsert: true, new: true }
        );
        res.json(updated);
    } catch (err) {
        res.status(500).json({ message: "Upload failed", error: err.message });
    }
});

module.exports = router;
