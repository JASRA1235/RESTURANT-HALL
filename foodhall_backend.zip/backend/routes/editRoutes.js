
const express = require("express");
const Content = require("../models/Content");
const verifyToken = require("../middleware/verifyToken");
const router = express.Router();

router.post("/text", verifyToken, async (req, res) => {
    const { section, text } = req.body;
    try {
        const updated = await Content.findOneAndUpdate(
            { section },
            { text },
            { upsert: true, new: true }
        );
        res.json(updated);
    } catch (err) {
        res.status(500).json({ message: "Update failed", error: err.message });
    }
});

router.get("/", async (req, res) => {
    try {
        const content = await Content.find({});
        res.json(content);
    } catch (err) {
        res.status(500).json({ message: "Failed to fetch", error: err.message });
    }
});

module.exports = router;
