
export const API_BASE = "https://restaurant-backend.onrender.com/api";
