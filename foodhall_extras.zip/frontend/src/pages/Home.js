
import React, { useEffect, useState } from "react";
import { API_BASE } from "../config";

function Home() {
  const [content, setContent] = useState([]);

  useEffect(() => {
    fetch(API_BASE + "/edit")
      .then((res) => res.json())
      .then(setContent);
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h1>Welcome to FOOD HALL</h1>
      {content.map((item) => (
        <div key={item.section} style={{ marginBottom: 30 }}>
          <h2>{item.section.toUpperCase()}</h2>
          {item.image && <img src={item.image} alt="" style={{ width: "100%", maxWidth: 400 }} />}
          <p>{item.text}</p>
        </div>
      ))}
    </div>
  );
}

export default Home;
