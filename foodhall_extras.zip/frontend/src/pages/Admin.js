
import React, { useEffect, useState } from "react";
import { API_BASE } from "../config";

function Admin() {
  const [content, setContent] = useState([]);
  const [token, setToken] = useState(localStorage.getItem("token"));

  useEffect(() => {
    fetch(API_BASE + "/edit")
      .then((res) => res.json())
      .then(setContent);
  }, []);

  const updateText = async (section, text) => {
    await fetch(API_BASE + "/edit/text", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
      body: JSON.stringify({ section, text }),
    });
  };

  const updateImage = async (section, image) => {
    await fetch(API_BASE + "/upload/image", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
      body: JSON.stringify({ section, image }),
    });
  };

  const handleFileChange = (e, section) => {
    const reader = new FileReader();
    reader.onload = () => {
      updateImage(section, reader.result);
    };
    reader.readAsDataURL(e.target.files[0]);
  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Admin Panel - FOOD HALL</h2>
      {content.map((item) => (
        <div key={item.section} style={{ marginBottom: 40 }}>
          <h3>{item.section.toUpperCase()}</h3>
          <textarea
            defaultValue={item.text}
            onBlur={(e) => updateText(item.section, e.target.value)}
            style={{ width: "100%", height: 100 }}
          />
          <br />
          <input type="file" onChange={(e) => handleFileChange(e, item.section)} />
          {item.image && (
            <div>
              <img src={item.image} alt="" style={{ maxWidth: "200px", marginTop: 10 }} />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default Admin;
