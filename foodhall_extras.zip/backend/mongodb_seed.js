
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

mongoose.connect("mongodb://localhost:27017/foodhall", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(async () => {
  const hash = await bcrypt.hash("KHALID X ADAN", 10);
  await User.create({ username: "JASR", password: hash });
  console.log("Admin user created!");
  process.exit();
});
